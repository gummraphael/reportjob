using Microsoft.Extensions.Options;
using ReportWorker.Options;

namespace ReportWorker.Services;

public sealed class AdaptiveThrottlePolicy
{
    private readonly AdaptiveThrottleOptions _t;
    private readonly TimeZoneInfo _tz;
    private readonly TimeSpan _dayStart;
    private readonly TimeSpan _dayEnd;

    public AdaptiveThrottlePolicy(IOptions<ReportOptions> opts)
    {
        _t = opts.Value.AdaptiveThrottle;
        _tz = TimeZoneInfo.FindSystemTimeZoneById(_t.TimeZoneId);
        _dayStart = TimeSpan.Parse(_t.DayStart);
        _dayEnd = TimeSpan.Parse(_t.DayEnd);
    }

    public (int chunkSize, int delayMs) GetCurrent(int fallbackChunkSize)
    {
        if (!_t.Enabled)
            return (fallbackChunkSize, 0);

        var localNow = TimeZoneInfo.ConvertTime(DateTimeOffset.UtcNow, _tz).TimeOfDay;

        var isDay = localNow >= _dayStart && localNow < _dayEnd;
        return isDay
            ? (chunkSize: _t.DayChunkSize, delayMs: _t.DayDelayMs)
            : (chunkSize: _t.NightChunkSize, delayMs: _t.NightDelayMs);
    }
}
