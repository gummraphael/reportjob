using System.Text;

namespace ReportWorker.Services;

public sealed class CsvStreamWriter
{
    public StreamWriter Create(string path)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var fs = new FileStream(path, FileMode.Create, FileAccess.Write, FileShare.Read, bufferSize: 1 << 20);
        return new StreamWriter(fs, new UTF8Encoding(encoderShouldEmitUTF8Identifier: true));
    }

    public static string Esc(string? value)
    {
        value ??= "";
        var mustQuote = value.Contains(',') || value.Contains('"') || value.Contains('\n') || value.Contains('\r');
        if (value.Contains('"')) value = value.Replace("\"", "\"\"");
        return mustQuote ? $"\"{value}\"" : value;
    }
}
