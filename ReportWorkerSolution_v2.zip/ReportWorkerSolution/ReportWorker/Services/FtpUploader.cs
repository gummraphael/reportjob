using FluentFTP;
using Microsoft.Extensions.Options;
using ReportWorker.Options;

namespace ReportWorker.Services;

public sealed class FtpUploader
{
    private readonly ReportOptions _opts;

    public FtpUploader(IOptions<ReportOptions> opts) => _opts = opts.Value;

    /// <summary>
    /// Upload "atômico": envia como .partial e renomeia para o nome final.
    /// </summary>
    public async Task<string> UploadPromoteAsync(string localPath, string remoteFileName, CancellationToken ct)
    {
        var folder = _opts.FtpRemoteFolder.TrimEnd('/');
        var remoteFinal = $"{folder}/{remoteFileName}";
        var remotePartial = remoteFinal + ".partial";

        using var ftp = new AsyncFtpClient(_opts.FtpHost, _opts.FtpUser, _opts.FtpPass);
        ftp.Config.EncryptionMode = FtpEncryptionMode.None; // ajuste se FTPS

        await ftp.Connect(ct);
        await ftp.CreateDirectory(folder, true, ct);

        var status = await ftp.UploadFile(localPath, remotePartial, FtpRemoteExists.Overwrite, true, FtpVerify.None, ct);
        if (status != FtpStatus.Success)
            throw new InvalidOperationException($"Falha upload FTP: {status}");

        if (await ftp.FileExists(remoteFinal, ct))
            await ftp.DeleteFile(remoteFinal, ct);

        await ftp.Rename(remotePartial, remoteFinal, ct);
        await ftp.Disconnect(ct);

        return remoteFinal;
    }
}
