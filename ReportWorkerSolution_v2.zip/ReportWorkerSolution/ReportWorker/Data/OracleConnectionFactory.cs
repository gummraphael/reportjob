using Oracle.ManagedDataAccess.Client;

namespace ReportWorker.Data;

public sealed class OracleConnectionFactory
{
    private readonly string _connStr;

    public OracleConnectionFactory(IConfiguration cfg)
    {
        _connStr = cfg.GetConnectionString("Db")
            ?? throw new InvalidOperationException("ConnectionStrings:Db não configurado.");
    }

    public OracleConnection Create() => new OracleConnection(_connStr);
}
