using Oracle.ManagedDataAccess.Client;

namespace ReportWorker.Data;

public sealed class OracleJobRepository
{
    private readonly OracleConnectionFactory _factory;

    public OracleJobRepository(OracleConnectionFactory factory) => _factory = factory;

    public sealed record Job(long Id, string ReportType, string ParamsJson);

    /// <summary>
    /// Retira 1 job da fila (PENDING) e marca como RUNNING, usando FOR UPDATE SKIP LOCKED.
    /// Lock é somente na linha da tabela REPORT_JOB.
    /// </summary>
    public async Task<Job?> TryDequeueAsync(string workerId, CancellationToken ct)
    {
        await using var conn = _factory.Create();
        await conn.OpenAsync(ct);

        await using var tx = conn.BeginTransaction();

        await using var cmd = conn.CreateCommand();
        cmd.Transaction = tx;
        cmd.BindByName = true;
        cmd.CommandText = @"
            SELECT ID, REPORT_TYPE, NVL(PARAMS_JSON,'{}') AS PARAMS_JSON
            FROM REPORT_JOB
            WHERE STATUS = 'PENDING'
            ORDER BY CREATED_AT
            FETCH FIRST 1 ROWS ONLY
            FOR UPDATE SKIP LOCKED";

        await using var r = await cmd.ExecuteReaderAsync(ct);
        if (!await r.ReadAsync(ct))
        {
            await tx.RollbackAsync(ct);
            return null;
        }

        var id = r.GetInt64(0);
        var type = r.GetString(1);
        var json = r.GetString(2);

        await using var upd = conn.CreateCommand();
        upd.Transaction = tx;
        upd.BindByName = true;
        upd.CommandText = @"
            UPDATE REPORT_JOB
               SET STATUS='RUNNING',
                   STARTED_AT=SYSTIMESTAMP,
                   WORKER_ID=:WID,
                   HEARTBEAT_AT=SYSTIMESTAMP,
                   ERROR_MESSAGE=NULL
             WHERE ID=:ID";
        upd.Parameters.Add(new OracleParameter("WID", workerId));
        upd.Parameters.Add(new OracleParameter("ID", id));
        await upd.ExecuteNonQueryAsync(ct);

        await tx.CommitAsync(ct);

        return new Job(id, type, json);
    }

    public async Task HeartbeatAsync(long jobId, long lastKey, CancellationToken ct)
    {
        await using var conn = _factory.Create();
        await conn.OpenAsync(ct);

        await using var cmd = conn.CreateCommand();
        cmd.BindByName = true;
        cmd.CommandText = @"
            UPDATE REPORT_JOB
               SET HEARTBEAT_AT=SYSTIMESTAMP,
                   LAST_KEY=:LAST_KEY
             WHERE ID=:ID AND STATUS='RUNNING'";
        cmd.Parameters.Add(new OracleParameter("LAST_KEY", lastKey));
        cmd.Parameters.Add(new OracleParameter("ID", jobId));
        await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task<bool> IsCancelledAsync(long jobId, CancellationToken ct)
    {
        await using var conn = _factory.Create();
        await conn.OpenAsync(ct);

        await using var cmd = conn.CreateCommand();
        cmd.BindByName = true;
        cmd.CommandText = @"SELECT COUNT(1) FROM REPORT_JOB WHERE ID=:ID AND STATUS='CANCELLED'";
        cmd.Parameters.Add(new OracleParameter("ID", jobId));
        var count = Convert.ToInt32(await cmd.ExecuteScalarAsync(ct));
        return count > 0;
    }

    public async Task MarkDoneAsync(long jobId, string fileName, string ftpPath, CancellationToken ct)
    {
        await using var conn = _factory.Create();
        await conn.OpenAsync(ct);

        await using var cmd = conn.CreateCommand();
        cmd.BindByName = true;
        cmd.CommandText = @"
            UPDATE REPORT_JOB
               SET STATUS='DONE',
                   FILE_NAME=:FN,
                   FTP_PATH=:FTP,
                   FINISHED_AT=SYSTIMESTAMP
             WHERE ID=:ID";
        cmd.Parameters.Add(new OracleParameter("FN", fileName));
        cmd.Parameters.Add(new OracleParameter("FTP", ftpPath));
        cmd.Parameters.Add(new OracleParameter("ID", jobId));
        await cmd.ExecuteNonQueryAsync(ct);
    }

    public async Task MarkFailedAsync(long jobId, string error, CancellationToken ct)
    {
        await using var conn = _factory.Create();
        await conn.OpenAsync(ct);

        await using var cmd = conn.CreateCommand();
        cmd.BindByName = true;
        cmd.CommandText = @"
            UPDATE REPORT_JOB
               SET STATUS='FAILED',
                   ERROR_MESSAGE=:ERR,
                   FINISHED_AT=SYSTIMESTAMP
             WHERE ID=:ID";
        cmd.Parameters.Add(new OracleParameter("ERR", error));
        cmd.Parameters.Add(new OracleParameter("ID", jobId));
        await cmd.ExecuteNonQueryAsync(ct);
    }

    /// <summary>
    /// Jobs em RUNNING com heartbeat antigo voltam para PENDING (worker morreu).
    /// </summary>
    public async Task RescueStuckJobsAsync(int stuckMinutes, CancellationToken ct)
    {
        await using var conn = _factory.Create();
        await conn.OpenAsync(ct);

        await using var cmd = conn.CreateCommand();
        cmd.BindByName = true;
        cmd.CommandText = @"
            UPDATE REPORT_JOB
               SET STATUS='PENDING',
                   WORKER_ID=NULL,
                   HEARTBEAT_AT=NULL
             WHERE STATUS='RUNNING'
               AND HEARTBEAT_AT IS NOT NULL
               AND HEARTBEAT_AT < (SYSTIMESTAMP - NUMTODSINTERVAL(:M, 'MINUTE'))";
        cmd.Parameters.Add(new OracleParameter("M", stuckMinutes));
        await cmd.ExecuteNonQueryAsync(ct);
    }
}
