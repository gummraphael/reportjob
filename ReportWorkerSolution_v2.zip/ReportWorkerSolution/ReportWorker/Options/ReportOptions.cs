namespace ReportWorker.Options;

public sealed class ReportOptions
{
    public int ChunkSize { get; set; } = 20000;
    public string OutputFolder { get; set; } = "/tmp/reports";

    public int HeartbeatSeconds { get; set; } = 15;
    public int StuckJobMinutes { get; set; } = 60;

    public AdaptiveThrottleOptions AdaptiveThrottle { get; set; } = new();

    public string FtpHost { get; set; } = "";
    public string FtpUser { get; set; } = "";
    public string FtpPass { get; set; } = "";
    public string FtpRemoteFolder { get; set; } = "/relatorios";
}

public sealed class AdaptiveThrottleOptions
{
    public bool Enabled { get; set; } = true;
    public string TimeZoneId { get; set; } = "America/Sao_Paulo";

    public string DayStart { get; set; } = "07:00";
    public string DayEnd { get; set; } = "22:00";

    public int DayDelayMs { get; set; } = 800;
    public int NightDelayMs { get; set; } = 150;

    public int DayChunkSize { get; set; } = 10000;
    public int NightChunkSize { get; set; } = 30000;
}
