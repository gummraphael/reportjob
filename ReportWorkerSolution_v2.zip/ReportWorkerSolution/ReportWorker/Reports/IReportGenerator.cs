using Oracle.ManagedDataAccess.Client;

namespace ReportWorker.Reports;

public interface IReportGenerator
{
    string ReportType { get; }

    /// <summary>
    /// Gera o CSV no caminho localFilePath usando streaming e retorna o lastKey final.
    /// Observação: o generator NÃO faz FTP e NÃO muda status; isso é responsabilidade do Worker.
    /// </summary>
    Task<long> GenerateAsync(
        OracleConnection conn,
        long jobId,
        string paramsJson,
        string localFilePath,
        ReportRuntime runtime,
        CancellationToken ct);
}

public sealed class ReportRuntime
{
    public required Func<(int chunkSize, int delayMs)> GetThrottle;
    public required Func<long, Task> HeartbeatAsync;
    public required Func<Task<bool>> IsCancelledAsync;
}

public sealed class ReportGeneratorRegistry
{
    private readonly IReadOnlyDictionary<string, IReportGenerator> _map;

    public ReportGeneratorRegistry(IEnumerable<IReportGenerator> generators)
        => _map = generators.ToDictionary(g => g.ReportType, StringComparer.OrdinalIgnoreCase);

    public IReportGenerator Get(string reportType)
        => _map.TryGetValue(reportType, out var gen)
            ? gen
            : throw new InvalidOperationException($"ReportType não registrado: {reportType}");
}
