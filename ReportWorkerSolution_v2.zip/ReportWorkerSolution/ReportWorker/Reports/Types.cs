namespace ReportWorker.Reports;

public static class Types
{
    public const string R1_CLIENTES    = "R1_CLIENTES";
    public const string R2_PEDIDOS     = "R2_PEDIDOS";
    public const string R3_PRODUTOS    = "R3_PRODUTOS";
    public const string R4_FINANCEIRO  = "R4_FINANCEIRO";
    public const string R5_CHECKLISTS  = "R5_CHECKLISTS";
    public const string R6_OCORRENCIAS = "R6_OCORRENCIAS";
    public const string R7_AUDITORIA   = "R7_AUDITORIA";
}
