using System.Text.Json;
using Oracle.ManagedDataAccess.Client;
using ReportWorker.Reports;
using ReportWorker.Services;

namespace ReportWorker.Reports.Generators;

public sealed class R2PedidosReport : IReportGenerator
{
    public string ReportType => Types.R2_PEDIDOS;

    private sealed record Params(DateTime DateFrom, DateTime DateTo, long? ClienteId);

    public async Task<long> GenerateAsync(
        OracleConnection conn,
        long jobId,
        string paramsJson,
        string localFilePath,
        ReportRuntime runtime,
        CancellationToken ct)
    {
        var p = JsonSerializer.Deserialize<Params>(paramsJson, new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
                ?? throw new InvalidOperationException("ParamsJson inválido para R2_PEDIDOS.");

        await using var sw = new CsvStreamWriter().Create(localFilePath);
        await sw.WriteLineAsync("PEDIDO_ID,DATA_PEDIDO,CLIENTE_ID,CLIENTE_NOME,VALOR_TOTAL");

        long lastKey = 0;

        while (true)
        {
            ct.ThrowIfCancellationRequested();
            if (await runtime.IsCancelledAsync())
                throw new InvalidOperationException("Job cancelado.");

            var (chunkSize, delayMs) = runtime.GetThrottle();

            await using var cmd = conn.CreateCommand();
            cmd.BindByName = true;
            cmd.CommandText = Sql;
            cmd.Parameters.Add(new OracleParameter("LAST_KEY", lastKey));
            cmd.Parameters.Add(new OracleParameter("TAKE", chunkSize));
            cmd.Parameters.Add(new OracleParameter("DATE_FROM", p.DateFrom));
            cmd.Parameters.Add(new OracleParameter("DATE_TO", p.DateTo));
            cmd.Parameters.Add(new OracleParameter("CLIENTE_ID", (object?)p.ClienteId ?? DBNull.Value));

            await using var r = await cmd.ExecuteReaderAsync(ct);

            int fetched = 0;
            while (await r.ReadAsync(ct))
            {
                fetched++;

                var pedidoId = r.GetInt64(0);
                var data = r.GetDateTime(1);
                var clienteId = r.GetInt64(2);
                var clienteNome = r.IsDBNull(3) ? "" : r.GetString(3);
                var total = r.IsDBNull(4) ? 0m : r.GetDecimal(4);

                await sw.WriteLineAsync(string.Join(",",
                    CsvStreamWriter.Esc(pedidoId.ToString()),
                    CsvStreamWriter.Esc(data.ToString("yyyy-MM-dd HH:mm:ss")),
                    CsvStreamWriter.Esc(clienteId.ToString()),
                    CsvStreamWriter.Esc(clienteNome),
                    CsvStreamWriter.Esc(total.ToString("0.00"))
                ));

                lastKey = pedidoId;
            }

            await sw.FlushAsync(ct);
            await runtime.HeartbeatAsync(lastKey);

            if (delayMs > 0) await Task.Delay(delayMs, ct);
            if (fetched == 0) break;
        }

        return lastKey;
    }

    // Ajuste para o seu schema real
    private const string Sql = @"
        SELECT
            p.ID            AS PEDIDO_ID,
            p.DATA          AS DATA_PEDIDO,
            c.ID            AS CLIENTE_ID,
            c.NOME          AS CLIENTE_NOME,
            p.VALOR_TOTAL   AS VALOR_TOTAL
        FROM PEDIDOS p
        JOIN CLIENTES c ON c.ID = p.CLIENTE_ID
        WHERE p.ID > :LAST_KEY
          AND p.DATA >= :DATE_FROM
          AND p.DATA <  :DATE_TO
          AND (:CLIENTE_ID IS NULL OR p.CLIENTE_ID = :CLIENTE_ID)
        ORDER BY p.ID
        FETCH NEXT :TAKE ROWS ONLY";
}
