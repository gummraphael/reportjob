using System.Text.Json;
using Oracle.ManagedDataAccess.Client;
using ReportWorker.Reports;
using ReportWorker.Services;

namespace ReportWorker.Reports.Generators;

public sealed class R1ClientesReport : IReportGenerator
{
    public string ReportType => Types.R1_CLIENTES;

    // Ajuste os parâmetros conforme seu domínio
    private sealed record Params();

    public async Task<long> GenerateAsync(
        OracleConnection conn,
        long jobId,
        string paramsJson,
        string localFilePath,
        ReportRuntime runtime,
        CancellationToken ct)
    {
        _ = JsonSerializer.Deserialize<Params>(paramsJson, new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
            ?? new Params();

        await using var sw = new CsvStreamWriter().Create(localFilePath);
        await sw.WriteLineAsync("ID,NOME");

        long lastKey = 0;

        while (true)
        {
            ct.ThrowIfCancellationRequested();
            if (await runtime.IsCancelledAsync())
                throw new InvalidOperationException("Job cancelado.");

            var (chunkSize, delayMs) = runtime.GetThrottle();

            await using var cmd = conn.CreateCommand();
            cmd.BindByName = true;
            cmd.CommandText = Sql;
            cmd.Parameters.Add(new OracleParameter("LAST_KEY", lastKey));
            cmd.Parameters.Add(new OracleParameter("TAKE", chunkSize));

            await using var r = await cmd.ExecuteReaderAsync(ct);

            int fetched = 0;
            while (await r.ReadAsync(ct))
            {
                fetched++;
                // TODO: mapear colunas e escrever CSV
                var id = r.GetInt64(0);
                await sw.WriteLineAsync(CsvStreamWriter.Esc(id.ToString()));
                lastKey = id;
            }

            await sw.FlushAsync(ct);
            await runtime.HeartbeatAsync(lastKey);

            if (delayMs > 0) await Task.Delay(delayMs, ct);
            if (fetched == 0) break;
        }

        return lastKey;
    }

    // TODO: Substituir pela SQL real do relatório (R1_CLIENTES)
    // Regra: somente leitura + paginação keyset pela PK/índice.
    private const string Sql = @"
        SELECT t.ID
        FROM SUA_TABELA t
        WHERE t.ID > :LAST_KEY
        ORDER BY t.ID
        FETCH NEXT :TAKE ROWS ONLY";
}
