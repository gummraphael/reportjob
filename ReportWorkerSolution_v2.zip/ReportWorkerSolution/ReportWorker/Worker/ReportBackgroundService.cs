using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;
using ReportWorker.Data;
using ReportWorker.Options;
using ReportWorker.Reports;
using ReportWorker.Services;

namespace ReportWorker.Worker;

public sealed class ReportBackgroundService : BackgroundService
{
    private readonly ILogger<ReportBackgroundService> _logger;
    private readonly OracleConnectionFactory _connFactory;
    private readonly OracleJobRepository _jobs;
    private readonly ReportGeneratorRegistry _registry;
    private readonly FtpUploader _ftp;
    private readonly AdaptiveThrottlePolicy _throttle;
    private readonly ReportOptions _opts;
    private readonly string _workerId;

    public ReportBackgroundService(
        ILogger<ReportBackgroundService> logger,
        OracleConnectionFactory connFactory,
        OracleJobRepository jobs,
        ReportGeneratorRegistry registry,
        FtpUploader ftp,
        AdaptiveThrottlePolicy throttle,
        IOptions<ReportOptions> opts)
    {
        _logger = logger;
        _connFactory = connFactory;
        _jobs = jobs;
        _registry = registry;
        _ftp = ftp;
        _throttle = throttle;
        _opts = opts.Value;

        _workerId = $"{Environment.MachineName}-{Guid.NewGuid():N}".Substring(0, 24);
        Directory.CreateDirectory(_opts.OutputFolder);
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        while (!stoppingToken.IsCancellationRequested)
        {
            // Resgate de jobs travados
            try { await _jobs.RescueStuckJobsAsync(_opts.StuckJobMinutes, stoppingToken); }
            catch (Exception ex) { _logger.LogWarning(ex, "RescueStuckJobs falhou (seguindo)."); }

            var job = await _jobs.TryDequeueAsync(_workerId, stoppingToken);
            if (job is null)
            {
                await Task.Delay(TimeSpan.FromSeconds(3), stoppingToken);
                continue;
            }

            await ProcessJobAsync(job, stoppingToken);
        }
    }

    private async Task ProcessJobAsync(OracleJobRepository.Job job, CancellationToken ct)
    {
        var jobId = job.Id;
        var fileName = $"job_{jobId}.csv";
        var localPath = Path.Combine(_opts.OutputFolder, fileName);

        _logger.LogInformation("Job {JobId} ({Type}) iniciado. WorkerId={WorkerId}", jobId, job.ReportType, _workerId);

        try
        {
            // Regerar é OK: sempre recomeça do zero.
            if (File.Exists(localPath)) File.Delete(localPath);

            await using var conn = _connFactory.Create();
            await conn.OpenAsync(ct);

            var gen = _registry.Get(job.ReportType);

            var runtime = new ReportRuntime
            {
                GetThrottle = () => _throttle.GetCurrent(_opts.ChunkSize),
                HeartbeatAsync = async (lastKey) => await _jobs.HeartbeatAsync(jobId, lastKey, ct),
                IsCancelledAsync = async () => await _jobs.IsCancelledAsync(jobId, ct)
            };

            var lastKey = await gen.GenerateAsync(conn, jobId, job.ParamsJson, localPath, runtime, ct);

            // Upload FTP atomicidade via .partial
            var ftpPath = await _ftp.UploadPromoteAsync(localPath, fileName, ct);

            await _jobs.MarkDoneAsync(jobId, fileName, ftpPath, ct);

            if (File.Exists(localPath))
                File.Delete(localPath);

            _logger.LogInformation("Job {JobId} DONE. lastKey={LastKey} ftp={Ftp}", jobId, lastKey, ftpPath);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Job {JobId} FAILED.", jobId);
            await _jobs.MarkFailedAsync(jobId, $"{ex.GetType().Name}: {ex.Message}", ct);

            if (File.Exists(localPath))
                File.Delete(localPath);
        }
    }
}
