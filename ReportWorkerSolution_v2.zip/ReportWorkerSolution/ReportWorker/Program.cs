using Microsoft.Extensions.Options;
using ReportWorker.Data;
using ReportWorker.Options;
using ReportWorker.Reports;
using ReportWorker.Services;
using ReportWorker.Worker;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.Configure<ReportOptions>(builder.Configuration.GetSection("Report"));

builder.Services.AddSingleton<OracleConnectionFactory>();
builder.Services.AddSingleton<OracleJobRepository>();

builder.Services.AddSingleton<CsvStreamWriter>();
builder.Services.AddSingleton<FtpUploader>();
builder.Services.AddSingleton<AdaptiveThrottlePolicy>();

// 7 relatórios (Strategy pattern)
builder.Services.AddSingleton<IReportGenerator, ReportWorker.Reports.Generators.R1ClientesReport>();
builder.Services.AddSingleton<IReportGenerator, ReportWorker.Reports.Generators.R2PedidosReport>();
builder.Services.AddSingleton<IReportGenerator, ReportWorker.Reports.Generators.R3ProdutosReport>();
builder.Services.AddSingleton<IReportGenerator, ReportWorker.Reports.Generators.R4FinanceiroReport>();
builder.Services.AddSingleton<IReportGenerator, ReportWorker.Reports.Generators.R5ChecklistsReport>();
builder.Services.AddSingleton<IReportGenerator, ReportWorker.Reports.Generators.R6OcorrenciasReport>();
builder.Services.AddSingleton<IReportGenerator, ReportWorker.Reports.Generators.R7AuditoriaReport>();

builder.Services.AddSingleton<ReportGeneratorRegistry>();

builder.Services.AddHostedService<ReportBackgroundService>();

var host = builder.Build();
host.Run();
