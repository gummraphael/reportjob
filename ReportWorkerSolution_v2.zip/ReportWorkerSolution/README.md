# ReportWorkerSolution

Worker .NET (net8.0) que consome jobs de uma tabela Oracle (REPORT_JOB), gera CSV em streaming e envia para FTP.
- Um único worker processa 1 job por vez.
- Concorrência segura via `FOR UPDATE SKIP LOCKED` (lock somente na linha do job).
- Leitura de dados do relatório é SOMENTE SELECT (sem locks nas tabelas do domínio).
- Throttle adaptativo: de dia puxa menos (chunks menores + delay), de noite puxa mais.

## Quem chama quem (fluxo)
Front -> BFF -> API -> (INSERT em REPORT_JOB com STATUS='PENDING')
Worker:
1) TryDequeueAsync() pega 1 job PENDING e marca RUNNING (WORKER_ID, STARTED_AT, HEARTBEAT_AT)
2) Resolve o gerador pelo REPORT_TYPE (Strategy)
3) Generator faz SELECT em chunks (keyset) e escreve CSV (streaming)
4) Worker faz upload FTP como `.partial` e renomeia para final
5) Worker marca DONE (FTP_PATH, FILE_NAME) ou FAILED (ERROR_MESSAGE)

## Configuração
Edite `appsettings.json`:
- ConnectionStrings:Db
- Report.OutputFolder
- Report.FtpHost/FtpUser/FtpPass/FtpRemoteFolder

Throttle adaptativo (opcional):
Report.AdaptiveThrottle.DayStart/DayEnd e delays/chunks.

## Rodar local
dotnet restore
dotnet run --project ReportWorker

## Criar job (exemplo)
INSERT INTO REPORT_JOB (REPORT_TYPE, PARAMS_JSON, STATUS)
VALUES ('R2_PEDIDOS', '{"dateFrom":"2026-01-01T00:00:00","dateTo":"2026-02-01T00:00:00","clienteId":123}', 'PENDING');

## Observação importante
Os 7 geradores estão no diretório `Reports/Generators`.
- `R2PedidosReport` está com SQL exemplo.
- Os demais estão como template: você deve trocar SQL e mapping para seu schema real.


## Ajuste da v2
- O arquivo CSV local é removido automaticamente tanto em caso de sucesso quanto em caso de falha, evitando acúmulo de arquivos no pod.
